import { useState, useEffect, useRef } from "react";
import { supabase } from "./supabase.js";

const ANTHROPIC_KEY = "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";

// ─── CSS ─────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --navy:     #0a1628;
  --navy-mid: #0f2040;
  --navy-lt:  #1a3a5c;
  --steel:    #2e5f8a;
  --steel-lt: #4a82b0;
  --brass:    #c9a84c;
  --brass-lt: #e8c96a;
  --white:    #f0f4f8;
  --muted:    #8aa4bc;
  --success:  #2ecc71;
  --error:    #e74c3c;
  --border:   rgba(74,130,176,0.25);
  --glow:     rgba(201,168,76,0.15);
  --font-display: 'Bebas Neue', sans-serif;
  --font-body:    'IBM Plex Sans', sans-serif;
  --font-mono:    'IBM Plex Mono', monospace;
}

body {
  background: var(--navy);
  color: var(--white);
  font-family: var(--font-body);
  min-height: 100vh;
  overflow-x: hidden;
}

body::before {
  content: '';
  position: fixed; inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  pointer-events: none; z-index: 0; opacity: 0.6;
}

::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--navy-mid); }
::-webkit-scrollbar-thumb { background: var(--steel); border-radius: 3px; }

.app { position: relative; z-index: 1; min-height: 100vh; display: flex; flex-direction: column; }

.header {
  border-bottom: 1px solid var(--border);
  background: linear-gradient(180deg, rgba(15,32,64,0.98) 0%, rgba(10,22,40,0.95) 100%);
  backdrop-filter: blur(12px);
  position: sticky; top: 0; z-index: 100;
  padding: 0 2rem;
}
.header-inner {
  max-width: 1200px; margin: 0 auto;
  display: flex; align-items: center; justify-content: space-between;
  height: 64px;
}
.logo { display: flex; align-items: center; gap: 12px; }
.logo-badge {
  width: 36px; height: 36px;
  background: linear-gradient(135deg, var(--brass) 0%, var(--brass-lt) 100%);
  border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-display); font-size: 18px; color: var(--navy);
  box-shadow: 0 0 16px var(--glow), 0 2px 8px rgba(0,0,0,0.4);
}
.logo-text { font-family: var(--font-display); font-size: 26px; letter-spacing: 2px; color: var(--white); }
.logo-sub { font-size: 10px; color: var(--brass); letter-spacing: 3px; text-transform: uppercase; font-weight: 600; }

.nav { display: flex; gap: 4px; }
.nav-btn {
  background: none; border: none; cursor: pointer;
  padding: 8px 16px; border-radius: 6px;
  font-family: var(--font-body); font-size: 13px; font-weight: 500;
  color: var(--muted); letter-spacing: 0.5px;
  transition: all 0.2s; display: flex; align-items: center; gap: 6px;
}
.nav-btn:hover { color: var(--white); background: rgba(255,255,255,0.05); }
.nav-btn.active { color: var(--brass); background: var(--glow); }

.main { flex: 1; max-width: 1200px; margin: 0 auto; width: 100%; padding: 2rem; }

.page-title { font-family: var(--font-display); font-size: clamp(32px, 5vw, 52px); letter-spacing: 3px; color: var(--white); line-height: 1.0; }
.page-title span { color: var(--brass); }
.page-sub { color: var(--muted); font-size: 13px; letter-spacing: 2px; text-transform: uppercase; margin-top: 6px; font-weight: 500; }

.card {
  background: linear-gradient(135deg, rgba(15,32,64,0.9) 0%, rgba(10,22,40,0.9) 100%);
  border: 1px solid var(--border);
  border-radius: 12px; padding: 24px;
  position: relative; overflow: hidden;
}
.card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--steel-lt), transparent);
  opacity: 0.6;
}
.card-gold::before { background: linear-gradient(90deg, transparent, var(--brass), transparent); opacity: 0.8; }

.upload-zone {
  border: 2px dashed var(--border); border-radius: 12px;
  padding: 48px 24px; text-align: center; cursor: pointer;
  transition: all 0.3s; background: rgba(10,22,40,0.6);
  position: relative; overflow: hidden;
}
.upload-zone:hover, .upload-zone.drag-over {
  border-color: var(--brass); background: var(--glow);
  box-shadow: 0 0 32px var(--glow);
}
.upload-icon { font-size: 48px; margin-bottom: 16px; display: block; }
.upload-title { font-family: var(--font-display); font-size: 24px; letter-spacing: 2px; color: var(--white); margin-bottom: 8px; }
.upload-hint { color: var(--muted); font-size: 13px; }
.upload-input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }

.btn {
  border: none; border-radius: 8px; cursor: pointer;
  font-family: var(--font-body); font-weight: 600;
  letter-spacing: 1px; text-transform: uppercase; font-size: 13px;
  transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px;
}
.btn-primary {
  background: linear-gradient(135deg, var(--brass) 0%, var(--brass-lt) 100%);
  color: var(--navy); padding: 12px 28px;
  box-shadow: 0 4px 16px var(--glow);
}
.btn-primary:hover { transform: translateY(-1px); box-shadow: 0 8px 24px var(--glow); }
.btn-primary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
.btn-secondary {
  background: rgba(74,130,176,0.15); color: var(--steel-lt);
  border: 1px solid var(--border); padding: 10px 20px;
}
.btn-secondary:hover { background: rgba(74,130,176,0.25); color: var(--white); }

.progress-bar { height: 6px; background: rgba(255,255,255,0.08); border-radius: 3px; overflow: hidden; }
.progress-fill {
  height: 100%; border-radius: 3px;
  background: linear-gradient(90deg, var(--steel) 0%, var(--brass) 100%);
  transition: width 0.6s ease; position: relative; overflow: hidden;
}
.progress-fill::after {
  content: ''; position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  animation: shimmer 2s infinite;
}
@keyframes shimmer { 0%{transform:translateX(-100%)} 100%{transform:translateX(100%)} }

.badge {
  display: inline-block; padding: 3px 10px; border-radius: 100px;
  font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase;
}
.badge-gold { background: var(--glow); color: var(--brass); border: 1px solid rgba(201,168,76,0.3); }
.badge-blue { background: rgba(74,130,176,0.15); color: var(--steel-lt); border: 1px solid var(--border); }
.badge-green { background: rgba(46,204,113,0.1); color: var(--success); border: 1px solid rgba(46,204,113,0.2); }

.topic-card {
  background: linear-gradient(135deg, rgba(15,32,64,0.95) 0%, rgba(10,22,40,0.95) 100%);
  border: 1px solid var(--border); border-radius: 10px; padding: 20px;
  display: flex; gap: 16px; align-items: flex-start;
  transition: all 0.25s; position: relative;
}
.topic-card:hover { border-color: var(--steel-lt); background: rgba(26,58,92,0.5); transform: translateX(4px); }
.topic-card::after {
  content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
  background: linear-gradient(180deg, var(--steel), var(--brass));
  border-radius: 3px 0 0 3px; opacity: 0; transition: opacity 0.25s;
}
.topic-card:hover::after { opacity: 1; }
.topic-num {
  font-family: var(--font-display); font-size: 28px;
  min-width: 48px; text-align: center; line-height: 1;
  background: linear-gradient(135deg, var(--steel-lt), var(--brass));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.topic-info { flex: 1; }
.topic-title { font-weight: 600; color: var(--white); margin-bottom: 8px; font-size: 15px; }
.topic-meta { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.topic-actions { display: flex; gap: 8px; align-items: center; }

.question-card {
  background: rgba(15,32,64,0.8); border: 1px solid var(--border);
  border-radius: 12px; padding: 28px;
  animation: fadeSlide 0.3s ease;
}
@keyframes fadeSlide { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }

.question-num { font-family: var(--font-mono); font-size: 11px; color: var(--brass); letter-spacing: 2px; text-transform: uppercase; margin-bottom: 12px; }
.question-text { font-size: 17px; font-weight: 500; line-height: 1.6; color: var(--white); margin-bottom: 24px; }

.option {
  border: 1px solid var(--border); border-radius: 8px;
  padding: 14px 18px; margin-bottom: 10px; cursor: pointer;
  display: flex; align-items: center; gap: 14px;
  transition: all 0.2s; background: rgba(10,22,40,0.6);
  font-size: 14px; color: var(--white);
}
.option:hover:not(.answered) { border-color: var(--steel-lt); background: rgba(74,130,176,0.1); }
.option.correct { border-color: var(--success); background: rgba(46,204,113,0.1); color: var(--success); }
.option.wrong { border-color: var(--error); background: rgba(231,76,60,0.1); color: var(--error); }
.option-letter { font-family: var(--font-display); font-size: 18px; min-width: 28px; text-align: center; color: var(--muted); }
.option.correct .option-letter { color: var(--success); }
.option.wrong .option-letter { color: var(--error); }

.explanation {
  margin-top: 16px; padding: 14px 16px;
  background: rgba(74,130,176,0.08); border-left: 3px solid var(--steel-lt);
  border-radius: 0 8px 8px 0; font-size: 13px; color: var(--muted); line-height: 1.7;
  animation: fadeSlide 0.3s ease;
}
.explanation strong { color: var(--steel-lt); }

.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
.stat-box {
  background: linear-gradient(135deg, rgba(15,32,64,0.95) 0%, rgba(10,22,40,0.95) 100%);
  border: 1px solid var(--border); border-radius: 10px;
  padding: 20px; text-align: center; position: relative; overflow: hidden;
}
.stat-box::before {
  content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--brass), transparent);
}
.stat-value { font-family: var(--font-display); font-size: 44px; color: var(--brass); line-height: 1; }
.stat-label { font-size: 11px; color: var(--muted); letter-spacing: 2px; text-transform: uppercase; margin-top: 6px; }

.loading-ring {
  width: 40px; height: 40px; border-radius: 50%;
  border: 3px solid rgba(201,168,76,0.15); border-top-color: var(--brass);
  animation: spin 0.8s linear infinite; margin: 0 auto;
}
@keyframes spin { to{transform:rotate(360deg)} }
.loading-text { font-family: var(--font-mono); font-size: 12px; color: var(--brass); letter-spacing: 2px; text-align: center; margin-top: 12px; animation: pulse 1.5s ease-in-out infinite; }
@keyframes pulse { 0%,100%{opacity:0.5} 50%{opacity:1} }

.divider { border: none; border-top: 1px solid var(--border); margin: 24px 0; }

.toast {
  position: fixed; bottom: 24px; right: 24px; z-index: 1000;
  background: var(--navy-lt); border: 1px solid var(--border);
  border-radius: 10px; padding: 14px 20px;
  font-size: 14px; font-weight: 500;
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  animation: slideUp 0.3s ease;
  display: flex; align-items: center; gap: 10px;
}
@keyframes slideUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
.toast-success { border-color: rgba(46,204,113,0.4); color: var(--success); }
.toast-error { border-color: rgba(231,76,60,0.4); color: var(--error); }

.result-score {
  font-family: var(--font-display); font-size: 96px; line-height: 1;
  background: linear-gradient(135deg, var(--steel-lt), var(--brass));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  text-align: center;
}
.result-label { text-align: center; font-size: 13px; letter-spacing: 3px; text-transform: uppercase; color: var(--muted); }

@media(max-width: 640px) {
  .main { padding: 1rem; }
  .nav-btn span { display: none; }
  .stat-grid { grid-template-columns: 1fr 1fr; }
}
`;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function scoreColor(s) {
  if (s >= 80) return "var(--success)";
  if (s >= 60) return "var(--brass)";
  return "var(--error)";
}

function Toast({ msg, type, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3200); return () => clearTimeout(t); }, []);
  return <div className={`toast toast-${type}`}><span>{type === "success" ? "✓" : "✕"}</span> {msg}</div>;
}

// ─── UPLOAD VIEW ──────────────────────────────────────────────────────────────
function UploadView({ onTopicAdded, onToast }) {
  const [drag, setDrag] = useState(false);
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState("");
  const inputRef = useRef();

  function handleFile(f) {
    if (!f) return;
    if (f.type !== "application/pdf") { onToast("Solo se admiten archivos PDF.", "error"); return; }
    if (f.size > 20 * 1024 * 1024) { onToast("El PDF no puede superar 20 MB.", "error"); return; }
    setFile(f);
    setTitle(f.name.replace(".pdf", "").replace(/_/g, " "));
  }

  async function handleUpload() {
    if (!file || !title.trim()) return;
    setUploading(true);

    try {
      // 1. Subir PDF a Supabase Storage
      setProgress("Subiendo PDF a la nube...");
      const fileName = `${Date.now()}_${file.name}`;
      const { data: storageData, error: storageError } = await supabase
        .storage
        .from("pdfs")
        .upload(fileName, file);

      if (storageError) throw new Error("Error subiendo PDF: " + storageError.message);

      const { data: { publicUrl } } = supabase.storage.from("pdfs").getPublicUrl(fileName);

      // 2. Extraer texto del PDF (básico con FileReader)
      setProgress("Procesando contenido del PDF...");
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      let pdfText = "";
      try {
        const decoder = new TextDecoder("utf-8", { fatal: false });
        const rawText = decoder.decode(uint8Array);
        // Extraer texto visible entre paréntesis en streams PDF
        const matches = rawText.match(/\(([^)]{3,200})\)/g) || [];
        pdfText = matches
          .map(m => m.slice(1, -1))
          .filter(t => /[a-záéíóúñüA-ZÁÉÍÓÚÑÜ]{3,}/.test(t))
          .join(" ")
          .substring(0, 4000);
      } catch (e) {
        pdfText = `Tema de oposición: ${title}`;
      }

      if (pdfText.length < 100) {
        pdfText = `Tema de oposición a Oficial del Cuerpo Nacional de Policía: ${title}. Este tema abarca los contenidos del programa oficial de la Escala Ejecutiva del CNP.`;
      }

      // 3. Guardar topic en base de datos
      setProgress("Guardando en base de datos...");
      const { data: topicData, error: topicError } = await supabase
        .from("topics")
        .insert({ title: title.trim(), pdf_url: publicUrl, pages: Math.ceil(file.size / 3000) })
        .select()
        .single();

      if (topicError) throw new Error("Error guardando tema: " + topicError.message);

      onTopicAdded({ ...topicData, tests: 0, avgScore: 0, accuracy: 0, lastTest: null, pdfText });
      onToast("¡Tema subido correctamente! Listo para generar test.", "success");
      setFile(null);
      setTitle("");

    } catch (err) {
      onToast(err.message || "Error al subir el tema.", "error");
    } finally {
      setUploading(false);
      setProgress("");
    }
  }

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <div className="page-title">SUBIR <span>TEMA</span></div>
        <div className="page-sub">Policía Nacional — Escala Ejecutiva · Oficial</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div className="card card-gold">
          <div style={{ marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 20, letterSpacing: 2 }}>ARCHIVO PDF</h2>
            {file && <span className="badge badge-green">✓ Seleccionado</span>}
          </div>

          <div
            className={`upload-zone${drag ? " drag-over" : ""}`}
            onDragOver={e => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
            onClick={() => inputRef.current?.click()}
          >
            <input ref={inputRef} type="file" accept=".pdf" className="upload-input"
              onChange={e => handleFile(e.target.files[0])} />
            <span className="upload-icon">{file ? "📄" : "⬆"}</span>
            <div className="upload-title">{file ? file.name : "SELECCIONA PDF"}</div>
            <div className="upload-hint">
              {file ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : "Toca para seleccionar · Máx. 20 MB"}
            </div>
          </div>

          <div style={{ marginTop: 20 }}>
            <label style={{ display: "block", fontSize: 12, letterSpacing: 2, color: "var(--muted)", textTransform: "uppercase", marginBottom: 8, fontWeight: 600 }}>
              Nombre del Tema
            </label>
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ej: Tema 6 — Código Penal"
              style={{
                width: "100%", padding: "12px 16px", borderRadius: 8,
                background: "rgba(10,22,40,0.8)", border: "1px solid var(--border)",
                color: "var(--white)", fontFamily: "var(--font-body)", fontSize: 14, outline: "none",
              }}
            />
          </div>

          {uploading && progress && (
            <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 10 }}>
              <div className="loading-ring" style={{ width: 18, height: 18, borderWidth: 2 }} />
              <span style={{ fontSize: 12, color: "var(--brass)", fontFamily: "var(--font-mono)" }}>{progress}</span>
            </div>
          )}

          <div style={{ marginTop: 20 }}>
            <button
              className="btn btn-primary"
              style={{ width: "100%", justifyContent: "center" }}
              disabled={!file || !title.trim() || uploading}
              onClick={handleUpload}
            >
              {uploading ? "Procesando..." : "↑ Subir y Procesar"}
            </button>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card">
            <h3 style={{ fontFamily: "var(--font-display)", fontSize: 16, letterSpacing: 2, marginBottom: 16, color: "var(--brass)" }}>
              ¿CÓMO FUNCIONA?
            </h3>
            {[
              ["01", "Sube el PDF de tu tema de oposición"],
              ["02", "Se almacena en la nube de forma segura"],
              ["03", "La IA genera 5 preguntas tipo test basadas en el texto real"],
              ["04", "Practica y ve tu progreso en el Dashboard"],
            ].map(([n, t]) => (
              <div key={n} style={{ display: "flex", gap: 12, marginBottom: 12, alignItems: "flex-start" }}>
                <span style={{ fontFamily: "var(--font-display)", fontSize: 20, color: "var(--brass)", minWidth: 28, lineHeight: 1.3 }}>{n}</span>
                <span style={{ fontSize: 14, color: "var(--muted)", lineHeight: 1.5 }}>{t}</span>
              </div>
            ))}
          </div>
          <div className="card">
            <h3 style={{ fontFamily: "var(--font-display)", fontSize: 16, letterSpacing: 2, marginBottom: 12, color: "var(--steel-lt)" }}>
              OPOSICIÓN ACTIVA
            </h3>
            <div style={{ fontSize: 14, color: "var(--muted)", lineHeight: 2 }}>
              <div>📋 <strong style={{ color: "var(--white)" }}>Cuerpo:</strong> Policía Nacional</div>
              <div>🎯 <strong style={{ color: "var(--white)" }}>Escala:</strong> Ejecutiva</div>
              <div>🏆 <strong style={{ color: "var(--white)" }}>Categoría:</strong> Oficial</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── TOPICS VIEW ──────────────────────────────────────────────────────────────
function TopicsView({ topics, onStartTest, loading }) {
  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 300, gap: 16 }}>
      <div className="loading-ring" />
      <div className="loading-text">CARGANDO TEMAS...</div>
    </div>
  );

  return (
    <div>
      <div style={{ marginBottom: 32, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div className="page-title">MIS <span>TEMAS</span></div>
          <div className="page-sub">{topics.length} temas cargados en el sistema</div>
        </div>
        <span className="badge badge-gold">{topics.length} temas</span>
      </div>

      {topics.length === 0 ? (
        <div className="card" style={{ textAlign: "center", padding: 48 }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📂</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 22, letterSpacing: 2, marginBottom: 8 }}>SIN TEMAS AÚN</div>
          <div style={{ color: "var(--muted)", fontSize: 14 }}>Sube tu primer PDF desde la sección "Subir Tema"</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {topics.map((topic, i) => (
            <div key={topic.id} className="topic-card">
              <div className="topic-num">{String(i + 1).padStart(2, "0")}</div>
              <div className="topic-info">
                <div className="topic-title">{topic.title}</div>
                <div className="topic-meta">
                  <span className="badge badge-blue">📄 {topic.pages} pág.</span>
                  <span className="badge badge-blue">🧪 {topic.tests} tests</span>
                  {topic.tests > 0 && (
                    <span className="badge" style={{
                      background: `rgba(${topic.accuracy >= 80 ? "46,204,113" : topic.accuracy >= 60 ? "201,168,76" : "231,76,60"},0.1)`,
                      color: scoreColor(topic.accuracy),
                      border: `1px solid ${scoreColor(topic.accuracy)}44`
                    }}>
                      ⚡ {topic.accuracy}% precisión
                    </span>
                  )}
                </div>
              </div>
              <div className="topic-actions">
                <button className="btn btn-primary" onClick={() => onStartTest(topic)}>
                  {topic.tests === 0 ? "Generar Test" : "Nuevo Test"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── TEST VIEW ────────────────────────────────────────────────────────────────
function TestView({ topic, onBack, onFinish, onToast }) {
  const currentTestId = useRef(null);
  const [loading, setLoading] = useState(true);
  const [loadingMsg, setLoadingMsg] = useState("Conectando con la IA...");
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [revealed, setRevealed] = useState({});
  const [finished, setFinished] = useState(false);

  useEffect(() => { generateTest(); }, []);

  async function generateTest() {
    setLoading(true);
    try {
      setLoadingMsg("Analizando tu PDF...");
      await new Promise(r => setTimeout(r, 600));
      setLoadingMsg("Generando preguntas con IA...");

      const pdfContext = topic.pdfText
        ? `Contenido extraído del PDF:\n${topic.pdfText}`
        : `Tema de oposición: "${topic.title}"`;

      const prompt = `Eres un examinador experto en oposiciones a Oficial de la Escala Ejecutiva del Cuerpo Nacional de Policía de España.

${pdfContext}

Basándote en el contenido anterior, genera 5 preguntas tipo test de dificultad alta, propias del nivel de Oficial CNP.
Cada pregunta debe tener 4 opciones (a, b, c, d) con una sola respuesta correcta.
Incluye una explicación breve citando el artículo o norma correspondiente.

Devuelve SOLO JSON válido con este formato exacto, sin texto adicional:
{
  "questions": [
    {
      "id": "q1",
      "text": "Pregunta aquí",
      "options": {"a": "opción a", "b": "opción b", "c": "opción c", "d": "opción d"},
      "correct": "a",
      "explanation": "Explicación con referencia legal"
    }
  ]
}`;

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": ANTHROPIC_KEY,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }]
        })
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error.message);

      const text = data.content.map(c => c.text || "").join("");
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setQuestions(parsed.questions);
    } catch (err) {
      onToast("Error generando preguntas: " + err.message, "error");
      onBack();
    } finally {
      setLoading(false);
    }
  }

  async function selectOption(optKey) {
    if (answers[current] !== undefined) return;
    const q = questions[current];
    const isCorrect = optKey === q.correct;
    setAnswers(prev => ({ ...prev, [current]: optKey }));
    setRevealed(prev => ({ ...prev, [current]: true }));

    // Guardar respuesta en Supabase
    try {
      await supabase.from("questions").insert({
        test_id: currentTestId.current,
        question_text: q.text,
        option_a: q.options.a, option_b: q.options.b,
        option_c: q.options.c, option_d: q.options.d,
        correct_option: q.correct,
        explanation: q.explanation,
        user_answer: optKey,
        is_correct: isCorrect
      });
    } catch (e) { /* no bloquear la UI */ }
  }

  async function finishTest() {
    const correct = Object.entries(answers).filter(([i, ans]) => ans === questions[i].correct).length;
    const score = Math.round((correct / questions.length) * 100);

    // Guardar test en Supabase
    try {
      await supabase.from("tests")
        .update({ score })
        .eq("id", currentTestId.current);
    } catch (e) { }

    onFinish(topic.id, score);
    setFinished(true);
  }

  // Crear test en BD al cargar preguntas
  useEffect(() => {
    if (questions.length > 0 && !currentTestId.current) {
      supabase.from("tests")
        .insert({ topic_id: topic.id, score: 0, total_questions: 5 })
        .select().single()
        .then(({ data }) => { if (data) currentTestId.current = data.id; });
    }
  }, [questions]);

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 400, gap: 16 }}>
      <div className="loading-ring" />
      <div className="loading-text">{loadingMsg}</div>
      <div style={{ fontSize: 12, color: "var(--muted)", textAlign: "center", maxWidth: 300 }}>
        {topic.title}
      </div>
    </div>
  );

  if (finished) {
    const correct = Object.entries(answers).filter(([i, ans]) => ans === questions[i].correct).length;
    const score = Math.round((correct / questions.length) * 100);
    return (
      <div>
        <div style={{ marginBottom: 32, textAlign: "center" }}>
          <div className="result-score">{score}%</div>
          <div className="result-label">Resultado del Test</div>
          <div style={{ marginTop: 12 }}>
            <span className="badge" style={{
              background: `rgba(${score >= 80 ? "46,204,113" : score >= 60 ? "201,168,76" : "231,76,60"},0.1)`,
              color: scoreColor(score), border: `1px solid ${scoreColor(score)}44`,
              fontSize: 14, padding: "6px 16px"
            }}>
              {correct} / {questions.length} correctas
            </span>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8, marginBottom: 32 }}>
          {questions.map((q, i) => {
            const ok = answers[i] === q.correct;
            return (
              <div key={i} style={{
                padding: 16, borderRadius: 8, textAlign: "center",
                background: ok ? "rgba(46,204,113,0.1)" : "rgba(231,76,60,0.1)",
                border: `1px solid ${ok ? "rgba(46,204,113,0.3)" : "rgba(231,76,60,0.3)"}`,
              }}>
                <div style={{ fontFamily: "var(--font-display)", fontSize: 24, color: ok ? "var(--success)" : "var(--error)" }}>
                  {ok ? "✓" : "✗"}
                </div>
                <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 4 }}>P{i + 1}</div>
              </div>
            );
          })}
        </div>

        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <button className="btn btn-secondary" onClick={onBack}>← Volver a Temas</button>
          <button className="btn btn-primary" onClick={() => { setFinished(false); setCurrent(0); setAnswers({}); setRevealed({}); generateTest(); }}>
            Nuevo Test
          </button>
        </div>
      </div>
    );
  }

  const q = questions[current];
  const answered = answers[current] !== undefined;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
        <div>
          <div className="page-title" style={{ fontSize: 28 }}><span>Test</span> · {topic.title.split("—")[0]}</div>
          <div className="page-sub">CNP · Escala Ejecutiva · Oficial</div>
        </div>
        <button className="btn btn-secondary" onClick={onBack}>✕ Salir</button>
      </div>

      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 12, color: "var(--muted)", letterSpacing: 1 }}>PREGUNTA {current + 1} DE {questions.length}</span>
          <span style={{ fontSize: 12, color: "var(--brass)", fontFamily: "var(--font-mono)" }}>{Object.keys(answers).length} respondidas</span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${((current + 1) / questions.length) * 100}%` }} />
        </div>
      </div>

      <div className="question-card">
        <div className="question-num">PREGUNTA {String(current + 1).padStart(2, "0")} · CNP OFICIAL</div>
        <div className="question-text">{q.text}</div>

        {["a", "b", "c", "d"].map(opt => {
          let cls = "option";
          if (answered) {
            if (opt === q.correct) cls += " correct";
            else if (opt === answers[current]) cls += " wrong";
          }
          return (
            <div key={opt} className={cls} onClick={() => selectOption(opt)}>
              <span className="option-letter">{opt.toUpperCase()}</span>
              <span>{q.options[opt]}</span>
            </div>
          );
        })}

        {revealed[current] && (
          <div className="explanation">
            <strong>Explicación:</strong> {q.explanation}
          </div>
        )}
      </div>

      <div style={{ marginTop: 20, display: "flex", justifyContent: "flex-end" }}>
        {answered && (
          <button className="btn btn-primary" onClick={() => {
            if (current < questions.length - 1) setCurrent(c => c + 1);
            else finishTest();
          }}>
            {current < questions.length - 1 ? "Siguiente →" : "Ver Resultado"}
          </button>
        )}
      </div>
    </div>
  );
}

// ─── DASHBOARD VIEW ───────────────────────────────────────────────────────────
function DashboardView({ topics }) {
  const totalTests = topics.reduce((s, t) => s + (t.tests || 0), 0);
  const scored = topics.filter(t => t.tests > 0);
  const avgScore = scored.length > 0 ? Math.round(scored.reduce((s, t) => s + t.accuracy, 0) / scored.length) : 0;
  const mastered = topics.filter(t => t.accuracy >= 80).length;

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <div className="page-title">DASHBOARD <span>PROGRESO</span></div>
        <div className="page-sub">Policía Nacional — Oficial · Actualizado ahora</div>
      </div>

      <div className="stat-grid" style={{ marginBottom: 32 }}>
        {[
          { value: topics.length, label: "Temas Cargados" },
          { value: totalTests, label: "Tests Realizados" },
          { value: `${avgScore}%`, label: "Media Global", color: scoreColor(avgScore) },
          { value: mastered, label: "Temas Dominados", color: "var(--success)" },
        ].map((s, i) => (
          <div key={i} className="stat-box">
            <div className="stat-value" style={s.color ? { color: s.color } : {}}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 18, letterSpacing: 2, marginBottom: 24, color: "var(--brass)" }}>
          RENDIMIENTO POR TEMA
        </h2>
        {topics.length === 0 ? (
          <div style={{ textAlign: "center", padding: 32, color: "var(--muted)" }}>
            Aún no hay temas. Sube tu primer PDF para empezar.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            {topics.map((topic, i) => (
              <div key={topic.id}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                  <div style={{ flex: 1, marginRight: 16 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "var(--white)", marginBottom: 3 }}>{topic.title}</div>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>
                      {topic.tests > 0 ? `${topic.tests} tests realizados` : "Sin tests aún"}
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ fontFamily: "var(--font-display)", fontSize: 28, color: topic.tests > 0 ? scoreColor(topic.accuracy) : "var(--muted)" }}>
                      {topic.tests > 0 ? `${topic.accuracy}%` : "—"}
                    </div>
                    <span className="badge" style={
                      topic.accuracy >= 80 ? { background: "rgba(46,204,113,0.1)", color: "var(--success)", border: "1px solid rgba(46,204,113,0.2)" }
                      : topic.accuracy >= 60 ? { background: "var(--glow)", color: "var(--brass)", border: "1px solid rgba(201,168,76,0.2)" }
                      : topic.tests === 0 ? { background: "rgba(255,255,255,0.05)", color: "var(--muted)", border: "1px solid var(--border)" }
                      : { background: "rgba(231,76,60,0.1)", color: "var(--error)", border: "1px solid rgba(231,76,60,0.2)" }
                    }>
                      {topic.accuracy >= 80 ? "DOMINADO" : topic.accuracy >= 60 ? "EN CURSO" : topic.tests === 0 ? "PENDIENTE" : "REFORZAR"}
                    </span>
                  </div>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${topic.accuracy || 0}%`, background: `linear-gradient(90deg, ${scoreColor(topic.accuracy || 0)}, ${scoreColor(topic.accuracy || 0)}aa)` }} />
                </div>
                {i < topics.length - 1 && <div className="divider" style={{ margin: "20px 0 0 0" }} />}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState("topics");
  const [topics, setTopics] = useState([]);
  const [topicsLoading, setTopicsLoading] = useState(true);
  const [activeTest, setActiveTest] = useState(null);
  const [toast, setToast] = useState(null);

  // Cargar temas desde Supabase al arrancar
  useEffect(() => {
    loadTopics();
  }, []);

  async function loadTopics() {
    setTopicsLoading(true);
    try {
      const { data: topicsData } = await supabase.from("topics").select("*").order("created_at", { ascending: false });
      const { data: testsData } = await supabase.from("tests").select("topic_id, score");

      const enriched = (topicsData || []).map(t => {
        const topicTests = (testsData || []).filter(ts => ts.topic_id === t.id);
        const avg = topicTests.length > 0
          ? Math.round(topicTests.reduce((s, ts) => s + ts.score, 0) / topicTests.length)
          : 0;
        return { ...t, tests: topicTests.length, avgScore: avg, accuracy: avg };
      });

      setTopics(enriched);
    } catch (e) {
      showToast("Error cargando temas: " + e.message, "error");
    } finally {
      setTopicsLoading(false);
    }
  }

  function showToast(msg, type = "success") {
    setToast({ msg, type, id: Date.now() });
  }

  function handleStartTest(topic) {
    setActiveTest(topic);
    setView("test");
  }

  function handleFinishTest(topicId, score) {
    setTopics(prev => prev.map(t => {
      if (t.id !== topicId) return t;
      const newTests = t.tests + 1;
      const newAvg = Math.round(((t.avgScore * t.tests) + score) / newTests);
      return { ...t, tests: newTests, avgScore: newAvg, accuracy: newAvg };
    }));
    showToast(`Test completado — Puntuación: ${score}%`, score >= 70 ? "success" : "error");
  }

  const navItems = [
    { id: "topics", icon: "📚", label: "Mis Temas" },
    { id: "upload", icon: "⬆", label: "Subir Tema" },
    { id: "dashboard", icon: "📊", label: "Dashboard" },
  ];

  if (view === "test" && activeTest) {
    return (
      <>
        <style>{CSS}</style>
        <div className="app">
          <header className="header">
            <div className="header-inner">
              <div className="logo">
                <div className="logo-badge">O</div>
                <div>
                  <div className="logo-text">OpoTool</div>
                  <div className="logo-sub">Oficial · CNP</div>
                </div>
              </div>
              <span className="badge badge-gold">⚡ Test en curso</span>
            </div>
          </header>
          <main className="main">
            <TestView topic={activeTest} onBack={() => { setView("topics"); loadTopics(); }} onFinish={handleFinishTest} onToast={showToast} />
          </main>
        </div>
        {toast && <Toast key={toast.id} msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </>
    );
  }

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <header className="header">
          <div className="header-inner">
            <div className="logo">
              <div className="logo-badge">O</div>
              <div>
                <div className="logo-text">OpoTool</div>
                <div className="logo-sub">Oficial · CNP</div>
              </div>
            </div>
            <nav className="nav">
              {navItems.map(n => (
                <button key={n.id} className={`nav-btn${view === n.id ? " active" : ""}`} onClick={() => setView(n.id)}>
                  <span>{n.icon}</span>
                  <span>{n.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </header>
        <main className="main">
          {view === "upload" && <UploadView onTopicAdded={t => { setTopics(p => [t, ...p]); setView("topics"); }} onToast={showToast} />}
          {view === "topics" && <TopicsView topics={topics} onStartTest={handleStartTest} loading={topicsLoading} />}
          {view === "dashboard" && <DashboardView topics={topics} />}
        </main>
      </div>
      {toast && <Toast key={toast.id} msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );
}
